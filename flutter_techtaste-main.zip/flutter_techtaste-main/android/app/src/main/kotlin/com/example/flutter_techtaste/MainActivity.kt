package com.example.flutter_techtaste

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
