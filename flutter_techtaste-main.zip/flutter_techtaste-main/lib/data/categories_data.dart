abstract class CategoriesData {
  static List<String> listCategories = [
    "Petiscos",
    "Principais",
    "Massas",
    "Sobremesas",
    "Bebidas",
  ];
}
